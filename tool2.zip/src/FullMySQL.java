//public class GetTableMySQL {
//    private String tablename;
//    private List<String> colum;
//}
